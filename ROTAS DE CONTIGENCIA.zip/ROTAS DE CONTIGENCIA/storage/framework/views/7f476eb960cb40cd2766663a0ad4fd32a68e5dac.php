<h3>Sobre Nós (view)</h3>
<?php /**PATH /home/alucard/Documents/trabalho/AULAS/Laravel/app_super_gestao/resources/views/site/sobre-nos.blade.php ENDPATH**/ ?>