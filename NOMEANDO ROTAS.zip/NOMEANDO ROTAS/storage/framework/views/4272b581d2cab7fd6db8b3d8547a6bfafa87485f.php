<h3>Contato (view)</h3>
<?php /**PATH /home/alucard/Documents/trabalho/AULAS/Laravel/app_super_gestao/resources/views/site/contato.blade.php ENDPATH**/ ?>