<h3>Principal (view)</h3>
<?php /**PATH /home/alucard/Documents/trabalho/AULAS/Laravel/app_super_gestao/resources/views/site/principal.blade.php ENDPATH**/ ?>