<h3>Principal (view)</h3>

<ul>
    <li>
        <a href="/">Principal</a>
    </li>
    <li>
        <a href="/sobre-nos">Sobre nós</a>
    </li>
    <li>
        <a href="/contato">Contato</a>
    </li>
</ul>
<?php /**PATH /home/alucard/Documents/trabalho/AULAS/Laravel/app_super_gestao/resources/views/site/principal.blade.php ENDPATH**/ ?>