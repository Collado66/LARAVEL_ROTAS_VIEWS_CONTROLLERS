<h3>Principal (view)</h3>

<ul>
    <li>
        <a href="/">Principal</a>
    </li>
    <li>
        <a href="/sobre-nos">Sobre nós</a>
    </li>
    <li>
        <a href="/contato">Contato</a>
    </li>
</ul>
